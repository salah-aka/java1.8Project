package ProjetPOO01.Enumerations;

public enum EAchat {

	Television,
	Telephone,
	Ordinateur,
	Livre,
	Dvd
	
}
