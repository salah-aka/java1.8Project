package projPOO01.GestionPersonnes;

import java.util.List;

import projPOO01.GestionAchat.commande;

/**Interface IFournisseur permet de d�finir des m�thodes qui sont propres au Fournisseur
 * @author Salaheddine El Majdoub
 *
 */
public interface IFournisseur {
	/**
	 * @return false par d�faut
	 */
	default public boolean livre() {
		return false;
	}
	
	
	  public void commande(List<commande> listcommande);
	
	
	/**
	 * @return true par d�faut
	 */
	default public boolean isFournisseur() {
		return true;
	}
}


