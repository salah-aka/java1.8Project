package projPOO01.GestionPersonnes;

import java.util.List;

import projPOO01.Exceptions.ExceptionContratAgence;
import projPOO01.GestionAchat.Achat;

/**
 * Represente une classe de gestion d�un int�rimaire qui h�rite de la classe
 * Salarie
 * 
 * @author Salaheddine El Majdoub 18/03/2020
 *
 */
public class Interimaire extends Salarie {
	/** contratAgence */
	private String contratAgence;
	/** dur�e en mois */
	private Integer dur�;

	/**
	 * constructeur
	 * 
	 * @param nom
	 * @param prenom
	 * @param adresse
	 * @param ville
	 * @param codepostal
	 * @param secu
	 * @param salaire
	 * @param contratAgence
	 * @param dur�e         en mois
	 */
	public Interimaire(String nom, String prenom, String adresse, String ville, String codepostal, String secu,
			double salaire, String contratAgence, Integer dur�) {
		super(nom, prenom, adresse, ville, codepostal, secu, salaire);
		this.setContratAgence(contratAgence);
		this.setDur�(dur�);
	}

	public static void CtrlSaisirint�rimaire(String contratAgence, Integer dur�) throws ExceptionContratAgence {
		if (contratAgence.length() > 5) {
			throw new ExceptionContratAgence("Le nombre de caract�re est inf�rieure � 5");
		}
			try {
				System.out.println(contratAgence);
			} catch (Exception e) {
				throw new ExceptionContratAgence("Il faut saisir uniquement des chiffres");
			}
		}

	@Override
	public boolean paie() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void achete(List<Achat> listachat) {
		// TODO Auto-generated method stub

	}

	/**
	 * Getter
	 * 
	 * @return contratAgence
	 */
	public String getContratAgence() {
		return contratAgence;
	}

	/**
	 * Setter
	 * 
	 * @param contratAgence
	 */
	public void setContratAgence(String contratAgence) {
		this.contratAgence = contratAgence;
	}

	/**
	 * Getter
	 * 
	 * @return Dur�e en mois
	 */
	public int getDur�() {
		return dur�;
	}

	/**
	 * Setter
	 * 
	 * @param dur�
	 */
	public void setDur�(int dur�) {
		this.dur� = dur�;
	}

}
