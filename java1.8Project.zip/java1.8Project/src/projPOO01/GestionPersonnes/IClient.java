package projPOO01.GestionPersonnes;

import java.util.List;

/**
 * cette classe est une interface qui met en evidence tous les methodes que le client peut l'implementer
 * @author formation
 *
 */
public interface IClient {
	/**
	 * 
	 * @return false par d�faut
	 */
	default public Boolean isClient() {
			return false;
		}
	/**
	 * Pr�voir un attribut de type List d'Object
	 * dans la classe qui va impl�menter cette interface
	 * @param la de type List d'Object
	 */
	 public void acheter(List<Object> a);
		

	/**
	 * 
	 * @return false par d�faut
	 */
	default public Boolean payer() {
		return false;
		}

	}
