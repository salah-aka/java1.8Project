package projPOO01.GestionPersonnes;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import ProjetPOO01.Enumerations.EFournisseur;
import projPOO01.Exceptions.ExceptionNumeroUnique;
import projPOO01.GestionAchat.Achat;
import projPOO01.GestionAchat.commande;

/**
 * cette classe permet de identifier le fournisseurs , ses commandes et affiche une exception sur un numero unique pour chaque founisseur
 * @author Salaheddine el majdoub
 *
 */
public abstract class Fournisseur extends Personne implements IClient, IFournisseur {

	/** idfournisseur */
	private int idfournisseur;
	/** commandes */
	private List<commande> commandes = new ArrayList<commande>();

	/**constructeur
	 * @param nom de fournisseur 
	 * @param prenom de fournisseur 
	 * @param adresse de fournisseur 
	 * @param ville de fournisseur 
	 * @param codepostal de fournisseur 
	 * @param idfournisseur 
	 */
	public Fournisseur(String nom, String prenom, String adresse, String ville, String codepostal, int idfournisseur) {
		super(nom, prenom, adresse, ville, codepostal);
		// TODO Auto-generated constructor stub
		this.idfournisseur = idfournisseur;
	}
	
	/**constructeur :Fournisseur
	 * @param di
	 */
	public Fournisseur(Dictionary<EFournisseur, String> di) {
		super(di.get(EFournisseur.nom), di.get(EFournisseur.prenom), di.get(EFournisseur.adresse), di.get(EFournisseur.ville), di.get(EFournisseur.codepostal));
		this.idfournisseur= Integer.parseInt(di.get(EFournisseur.idfournisseur));
	}
	
	/**Getter
	 * @return la commande 
	 */
	public List<commande> getCommandes() {
		return commandes;
	}

	@Override
	public String toString() {
		return super.toString() + "[idfournisseur=" + idfournisseur + ", commandes=" + commandes+"]";
	}

	/**Getter
	 * @return Id de Fournisseur 
	 */
	public int getIdfournisseur() {
		return idfournisseur;
	}


	/**Setter
	 * @param idfournisseur
	 */
	public void setIdfournisseur(int idfournisseur) {
		this.idfournisseur = idfournisseur;
	}

	public static void CtrlNumeroUniqueFournisseur(String ns, ArrayList<Fournisseur> list) throws ExceptionNumeroUnique{
		int n=0;
		try {
			 n = Integer.parseInt(ns);
		}catch(Exception e) {
			throw new ExceptionNumeroUnique("Le numero saisi n'est pas un entier");
		}
		for(Fournisseur c1:list) 
		{
			if(n!=c1.getIdfournisseur()) {
				
			}else {
				throw new ExceptionNumeroUnique("Le numero unique est d�ja utilis�");
			}
		}		
	}
}
